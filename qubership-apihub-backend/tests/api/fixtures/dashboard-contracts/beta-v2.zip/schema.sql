CREATE TABLE public.beta_items (
    id INTEGER PRIMARY KEY,
    code VARCHAR(50) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE
);
